#!/usr/bin/env python
# license removed for brevity
import rospy
from std_msgs.msg import Float64
import math 


def talker():
    # sub = rospy.Subscriber('snake_position', __somecustommsg_, __callback__)
    

    pub = rospy.Publisher('/new3/joint1_position_controller/command', Float64, queue_size=10)
    rospy.init_node('talker', anonymous=True)
    rate = rospy.Rate(1) # 10hz
    limit = 0.4
    start = rospy.Time.now().to_sec()
    while not rospy.is_shutdown():
        time_elapsed = rospy.Time.now().to_sec() - start
        # if (time_elapsed)>3:
        #     rotate_angle *= -1


        # we want the sine wave to make a fulle cycle in 60 seconds
        # so we scaled the time elapsed 
        rotate_angle = 0.4*math.sin(time_elapsed/60 * 2 * math.pi)

    
        rospy.loginfo(rotate_angle)
        pub.publish(rotate_angle)
        rate.sleep()

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass