#!/usr/bin/env python
# license removed for brevity
import rospy
from std_msgs.msg import Float64
import math 


def talker(number_of_snake_segments):
	publishers = {}
	for i in range(1, 2*number_of_snake_segments):
		publishers['pub%d'%i] = rospy.Publisher('/new3/joint%d_position_controller/command'%i, Float64, queue_size=10)
		rospy.init_node('talker', anonymous=True)
		rate = rospy.Rate(100) # 10hz
		limit = 0.4
		start = rospy.Time.now().to_sec()
	while not rospy.is_shutdown():
		time_elapsed = rospy.Time.now().to_sec() - start

		# we want the sine wave to make a fulle cycle in 60 seconds
		# so we scaled the time elapsed 
		rotate_angle = 0.4*math.sin(time_elapsed * 2 * math.pi)

		rospy.loginfo(rotate_angle)
		for k,v in publishers.items():

			
			if (int(k[3:]) % 14) in [k for k in range(1,8)]:
				v.publish(rotate_angle)
			elif (int(k[3:]) % 14) in [l for l in range(8, 15)]:
				v.publish(-1*rotate_angle)
		rate.sleep()

if __name__ == '__main__':
	try:
		number_of_snake_segments = 15
		talker(number_of_snake_segments)
	except rospy.ROSInterruptException:
		pass
